import React from "react";
import NumberSumsPrototype from "./NumberSums_Prototype_Vibe";

function App() {
  return <NumberSumsPrototype />;
}

export default App;
