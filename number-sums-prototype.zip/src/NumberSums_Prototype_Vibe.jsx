
import React, { useState, useEffect } from 'react';

const idx = (r, c, n) => r * n + c;

const levels = [
  {
    id: 1,
    title: 'Stage 1 — Beginner (3x3)',
    size: 3,
    board: [1,2,3,4,5,6,7,8,9],
    rowTargets: [6,15,24],
    colTargets: [12,15,18],
    regions: [
      { name: 'A', cells: [idx(0,0,3), idx(0,1,3)], target: 3 },
      { name: 'B', cells: [idx(0,2,3), idx(1,2,3)], target: 9 },
      { name: 'C', cells: [idx(1,0,3), idx(2,0,3)], target: 11 },
    ],
  },
  {
    id: 2,
    title: 'Stage 2 — Easy (4x4)',
    size: 4,
    board: [1,2,3,4,4,3,2,1,2,2,3,3,1,4,2,3],
    rowTargets: [10,10,10,10],
    colTargets: [8,11,10,4],
    regions: [
      { name: 'A', cells: [0,1,4,5], target: 10 },
      { name: 'B', cells: [2,3,6,7], target: 10 },
      { name: 'C', cells: [8,9,12,13], target: 8 },
    ],
  },
  {
    id: 3,
    title: 'Stage 3 — Medium (5x5)',
    size: 5,
    board: [1,2,3,4,5,2,3,4,1,2,3,1,2,3,1,4,2,1,2,3,1,3,2,4,2],
    rowTargets: [15,12,9,12,12],
    colTargets: [11,11,12,12,10],
    regions: [
      { name: 'A', cells: [0,1,5,6], target: 8 },
      { name: 'B', cells: [2,3,7,8,12], target: 13 },
      { name: 'C', cells: [10,11,15,16], target: 6 },
      { name: 'D', cells: [18,19,23,24], target: 11 },
    ],
  }
];

export default function NumberSumsPrototype() {
  const [levelIndex, setLevelIndex] = useState(0);
  const level = levels[levelIndex];
  const [cellState, setCellState] = useState(() => Array(level.board.length).fill('neutral'));
  const [mode, setMode] = useState('circle');
  const [message, setMessage] = useState('');

  useEffect(() => {
    setCellState(Array(level.board.length).fill('neutral'));
    setMessage('');
    setMode('circle');
  }, [levelIndex]);

  function toggleCell(i) {
    setCellState(prev => {
      const next = [...prev];
      if (mode === 'circle') next[i] = next[i] === 'circled' ? 'neutral' : 'circled';
      else next[i] = next[i] === 'erased' ? 'neutral' : 'erased';
      return next;
    });
  }

  function checkSolution() {
    const n = level.size;
    const sumAt = (indices) => indices.reduce((acc, id) => acc + (cellState[id] === 'circled' ? level.board[id] : 0), 0);
    for (let r = 0; r < n; r++) {
      const rowIdx = Array.from({ length: n }, (_, c) => idx(r, c, n));
      const s = sumAt(rowIdx);
      if (s !== level.rowTargets[r]) { setMessage(`Row ${r+1} sum ${s} ≠ ${level.rowTargets[r]}`); return false; }
    }
    for (let c = 0; c < n; c++) {
      const colIdx = Array.from({ length: n }, (_, r) => idx(r, c, n));
      const s = sumAt(colIdx);
      if (s !== level.colTargets[c]) { setMessage(`Column ${c+1} sum ${s} ≠ ${level.colTargets[c]}`); return false; }
    }
    for (const region of level.regions) {
      const s = sumAt(region.cells);
      if (s !== region.target) { setMessage(`Region ${region.name} sum ${s} ≠ ${region.target}`); return false; }
    }
    setMessage('Perfect! Level solved.');
    return true;
  }

  function revealSolution() {
    const next = Array(level.board.length).fill('neutral');
    for (const region of level.regions) { for (const c of region.cells) next[c] = 'circled'; }
    setCellState(next);
    setMessage('Revealed a candidate solution (demo).');
  }

  return (
    <div className="p-4 max-w-4xl mx-auto">
      <header className="mb-4">
        <h1 className="text-2xl font-bold">Number Sums — Prototype</h1>
        <p className="text-sm opacity-80">Stage: {level.title}</p>
      </header>
      <div className="flex items-center gap-2 mb-4">
        <button onClick={() => setLevelIndex(i => Math.max(0,i-1))} disabled={levelIndex===0}>Prev</button>
        <button onClick={() => setLevelIndex(i => Math.min(levels.length-1,i+1))} disabled={levelIndex===levels.length-1}>Next</button>
        <div className="ml-4">
          <label className="mr-2">Mode:</label>
          <button className={mode==='circle'?'bg-green-100':''} onClick={() => setMode('circle')}>Circle</button>
          <button className={mode==='erase'?'bg-red-100':''} onClick={() => setMode('erase')}>Erase</button>
        </div>
        <div className="ml-auto flex gap-2">
          <button onClick={checkSolution}>Check</button>
          <button onClick={revealSolution}>Reveal</button>
        </div>
      </div>
      <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${level.size}, minmax(56px, 1fr))` }}>
        {level.board.map((val,i)=>(
          <div key={i} onClick={()=>toggleCell(i)} className={`p-3 h-14 flex items-center justify-center border rounded select-none cursor-pointer relative ${cellState[i]==='circled'?'ring-4 ring-green-300 bg-green-50':''} ${cellState[i]==='erased'?'opacity-30 line-through bg-gray-100':''}`}>
            <div className="text-lg font-semibold">{val}</div>
          </div>
        ))}
      </div>
      <div className="mt-4 text-sm text-indigo-700">{message}</div>
    </div>
  );
}
