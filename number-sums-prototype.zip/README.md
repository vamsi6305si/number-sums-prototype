# Number Sums Puzzle Prototype

This is a **prototype implementation** of the Number Sums Puzzle using React.  
The prototype is created as part of an assignment task.

## Features
- 3 playable stages (3x3, 4x4, 5x5)
- Circle / Erase modes for cell selection
- Row, Column, and Region sum validation
- Check button to verify solution
- Reveal (demo) option

## Running Locally
1. Clone this repo and navigate to folder
2. Install dependencies: npm install
3. Run development server: npm start
